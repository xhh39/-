<?php

/**
 * 新闻小程序 -移动互联网开发课程 -杨
 * Plugin Name:		yydrifter Zixun Mini Program
 * Version:			5.0
 * Author:			yy凖
 * Author URI:		https://yydrifter.com/

 * Text Domain:		yydrifter-api
 */

if (!defined('WPINC')) {
	die;
}

define('YY_DRIFTER_API_VERSION', '5.0');
define('YY_DRIFTER_API_BASE_DIR', plugin_dir_path(__FILE__));
define('YY_DRIFTER_API_BASE_NAME', plugin_basename(__FILE__));
define('YY_DRIFTER_API_BASE_URL', plugin_dir_url(__FILE__));

function activate_yydrifter_api()
{
	require_once YY_DRIFTER_API_BASE_DIR . 'includes/class-yydrifter-api-activator.php';
	yydrifter_API_Activator::activate();
}

function deactivate_yydrifter_api()
{
	require_once YY_DRIFTER_API_BASE_DIR . 'includes/class-yydrifter-api-deactivator.php';
	yydrifter_API_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_yydrifter_api');
register_deactivation_hook(__FILE__, 'deactivate_yydrifter_api');

function yydrifter_api_action_links($actions)
{
	$actions[] = '<a href="admin.php?page=yydrifter-api">设置</a>';
    return $actions;
}
add_filter('plugin_action_links_' . YY_DRIFTER_API_BASE_NAME, 'yydrifter_api_action_links');

require YY_DRIFTER_API_BASE_DIR . 'includes/class-yydrifter-api.php';
require YY_DRIFTER_API_BASE_DIR . 'includes/yydrifter-function.php';
require YY_DRIFTER_API_BASE_DIR . 'includes/categories-images.php';
require YY_DRIFTER_API_BASE_DIR . 'includes/custom_users_column.php';
require YY_DRIFTER_API_BASE_DIR . 'includes/custom_dashboard.php';

global $pbt_prefix_yydrifter_api;
$pbt_prefix_yydrifter_api = new yydrifter_API();
$pbt_prefix_yydrifter_api->run();
