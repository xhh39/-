<?php

/*
 * 新闻版
 * Author: yy凖
 */

function yydrifter_api_custom_dashboard_help()
{
	$content = '欢迎使用yy凖平台!';
	echo $content;
}

function yydrifter_api_add_dashboard_widgets()
{
	wp_add_dashboard_widget('yydrifter_dashboard_widget', '新闻资讯后台', 'yydrifter_api_custom_dashboard_help');
}

add_action('wp_dashboard_setup', 'yydrifter_api_add_dashboard_widgets');
