<?php

/*
 * 新闻版
 * Author: yy凖
 * License：MIT
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

class yydrifter_API_i18n
{
	public function load_plugin_textdomain()
	{
		load_plugin_textdomain(
			'yydrifter-api',
			false,
			dirname(YY_DRIFTER_API_BASE_NAME) . '/languages/'
		);
	}
}
