<?php

/*
 * 新闻版
 * Author: yy凖
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

class yydrifter_API_Deactivator {

	public static function deactivate() {

	}

}
