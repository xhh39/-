<?php

/*
 * 新闻版
 * Author: yy凖
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

class yydrifter_API_Activator
{
    public static function activate()
    {
        global $wpdb;

        $charset_collate = '';
        if (!empty($wpdb->charset)) {
            $charset_collate = "DEFAULT CHARACTER SET {$wpdb->charset}";
        }

        if (!empty($wpdb->collate)) {
            $charset_collate .= " COLLATE {$wpdb->collate}";
        }

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        $table_post_view = $wpdb->prefix . 'yydrifter_post_view';
        $sql = "CREATE TABLE IF NOT EXISTS `$table_post_view` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
          `post_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '文章ID',
          `time` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
          PRIMARY KEY (`id`)
        ) $charset_collate;";
        dbDelta($sql);

        $table_post_like = $wpdb->prefix . 'yydrifter_post_like';
        $sql = "CREATE TABLE IF NOT EXISTS `$table_post_like` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
          `post_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '文章ID',
          `time` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
          PRIMARY KEY (`id`)
        ) $charset_collate;";
        dbDelta($sql);

        $table_post_favorite = $wpdb->prefix . 'yydrifter_post_favorite';
        $sql = "CREATE TABLE IF NOT EXISTS `$table_post_favorite` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
          `post_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '文章ID',
          `time` int(11) NOT NULL DEFAULT '0' COMMENT '时间',
          PRIMARY KEY (`id`)
        ) $charset_collate;";
        dbDelta($sql);

        //搜索
        $table_post_search = $wpdb->prefix . 'yydrifter_post_search';
        $sql = "CREATE TABLE IF NOT EXISTS `$table_post_search` (
          `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
          `search` varchar(250) NOT NULL DEFAULT '' COMMENT '搜索关键字',
          `times` int(11) NOT NULL DEFAULT 0 COMMENT '次数',
          PRIMARY KEY (`id`)
        ) $charset_collate;";
        dbDelta($sql);
    }
}
