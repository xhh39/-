<?php

/*
 * 新闻小程序 -移动互联网开发课程 -杨
 * Author: yy凖 -yyDrifter
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

//delete_option("yydrifter-api");
