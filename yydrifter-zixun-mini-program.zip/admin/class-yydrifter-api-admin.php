<?php

/*
 * 新闻版
 * Author: yy凖
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

class yydrifter_API_Admin
{
    private $yydrifter_api;

    private $version;

    public $main;

    public function __construct($yydrifter_api, $version, $plugin_main)
    {
        $this->yydrifter_api = $yydrifter_api;
        $this->version = $version;
        $this->main = $plugin_main;
    }

    public function enqueue_styles()
    {
        wp_enqueue_style($this->yydrifter_api, YY_DRIFTER_API_BASE_URL . 'admin/css/yydrifter-api-admin.css', array(), $this->version, 'all');
    }

    public function enqueue_scripts()
    {
        wp_enqueue_script($this->yydrifter_api, YY_DRIFTER_API_BASE_URL . 'admin/js/yydrifter-api-admin.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->yydrifter_api . '_edit_extend', YY_DRIFTER_API_BASE_URL . 'admin/js/yydrifter-api-edit-extend.js', array('quicktags'), $this->version, false);
    }

    public function create_menu()
	{
		$prefix = 'yydrifter-api';

		CSF::createOptions($prefix, array(
            'framework_title' => '新闻资讯后台 <small>by <a href="https://yydrifter.com" target="_blank" title="新闻资讯后台">yydrifter.com</a></small>',
			'menu_title' => '新闻资讯后台',
			'menu_slug'  => 'yydrifter-api',
			'menu_position' => 2,
            'footer_credit' => 'Thank you for creating with <a href="https://yydrifter.com/" target="_blank">yy凖</a>'
		));

		$base_dir = plugin_dir_path(__FILE__);
		$base_url = plugin_dir_url(__FILE__);

		require_once $base_dir . 'partials/overview.php';
		require_once $base_dir . 'partials/global.php';
		require_once $base_dir . 'partials/home.php';
        require_once $base_dir . 'partials/category.php';
        require_once $base_dir . 'partials/hot.php';
		require_once $base_dir . 'partials/profile.php';
	}

    public function admin_init()
	{
        $this->handle_external_redirects();
    }

    public function admin_menu()
	{
        add_submenu_page('yydrifter-api', '', ' ', 'manage_options', 'yydrifter_xcx_zixun_setup', array( &$this, 'handle_external_redirects' ) );
        add_submenu_page('yydrifter-api', '', ' ', 'manage_options', 'yydrifter_xcx_zixun_upgrade', array( &$this, 'handle_external_redirects' ) );
    }

    public function handle_external_redirects()
    {
      if (empty($_GET['page'])) {
        return;
      }

      if ('yydrifter_xcx_zixun_setup' === $_GET['page']) {
        wp_redirect('https://yydrifter.com/ky/4655.html');
        die;
      }

      if ('yydrifter_xcx_zixun_upgrade' === $_GET['page']) {
        wp_redirect('https://yydrifter.com/ky/4639.html');
        die;
      }
    }
}
