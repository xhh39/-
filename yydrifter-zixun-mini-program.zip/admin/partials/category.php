<?php

/*
 * 新闻版
 * Author: yy凖
 * Help document: https://yydrifter.com/docs/kaiyuan/id1
 * github: https://github.com/longwenjunjie/yydrifter_kafei
 * gitee: https://gitee.com/longwenjunj/yydrifter_kafei
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

// 分类设置
CSF::createSection($prefix, array(
    'id'    => 'category',
    'title' => '分类设置',
    'icon'  => 'fas fa-plus-circle',
    'fields' => array(
        
        array(
            'id'      => 'category_background',
            'type'    => 'media',
            'title'   => '背景图',
            'subtitle'   => '分类背景图',
            'library' => 'image',
        ),

        array(
            'id'          => 'category_title',
            'type'        => 'text',
            'title'       => '分类标题',
            'placeholder' => '请输入分类标题'
        ),

        array(
            'id'          => 'category_description',
            'type'        => 'text',
            'title'       => '分类描述',
            'placeholder' => '请输入分类描述'
        ),
        
    )
));
