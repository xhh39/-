<?php

/*
 * 新闻版
 * Author: yy凖
 * Help document: https://yydrifter.com/docs/kaiyuan/id1
 * github: https://github.com/longwenjunjie/yydrifter_kafei
 * gitee: https://gitee.com/longwenjunj/yydrifter_kafei
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

$content = '在yydrifter新闻资讯后台更改前端设置';


// 概要
CSF::createSection($prefix, array(
    'title'  => '概要',
    'icon'   => 'fas fa-rocket',
    'fields' => array(

        array(
            'type'    => 'content',
            'content' => $content,
        ),

    )
));
