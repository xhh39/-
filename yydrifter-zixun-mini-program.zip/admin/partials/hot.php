<?php

/*
 * 新闻版
 * Author: yy凖
 * Help document: https://yydrifter.com/docs/kaiyuan/id1
 * github: https://github.com/longwenjunjie/yydrifter_kafei
 * gitee: https://gitee.com/longwenjunj/yydrifter_kafei
 * Copyright ️© 2020-2021 yydrifter.com All rights reserved.
 */

// 热榜设置
CSF::createSection($prefix, array(
    'id'    => 'other',
    'title' => '热榜设置',
    'icon'  => 'fas fa-plus-circle',
    'fields' => array(
        
        array(
            'id'      => 'hot_background',
            'type'    => 'media',
            'title'   => '背景图',
            'subtitle'   => '热门背景图',
            'library' => 'image',
        ),

        array(
            'id'          => 'hot_title',
            'type'        => 'text',
            'title'       => '分类标题',
            'placeholder' => '请输入热门标题'
        ),

        array(
            'id'          => 'hot_description',
            'type'        => 'text',
            'title'       => '分类描述',
            'placeholder' => '请输入热门描述'
        ),

    )
));
